package com.example.blackjack_note.listeners;

import com.example.blackjack_note.entities.Note;

public interface NotesListener {
    void onNoteClicked(Note note, int position);
}
